<?php
/**
* 2015-2018 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
* @author    PrestaShop SA <contact@prestashop.com>
* @copyright 2015-2018 PrestaShop SA
* @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

class SampleDataHtml
{
	public function initData($base_url)
	{
		$content_block1 = '
			<ul class="d-inline-block head-coupen hidden-md-down">
			<li class="hidden-sm hidden-xs"><b>COUPON :</b> GROCERY10OFF</li>
			</ul>
		';
		
		$content_block2 = '
			<div class="d-inline-block hidden-md-down"><span class="call-img"></span>
			<div class="cartco"><span>Call us:</span><br /><span id="cart-total">123456789</span></div>
			</div>
		';
		
		$content_block3 = '
			<div class="container">
			<div class="service">
			<div>
			<div class="row">
			<ul class="col-xs-12 col-sm-3 col-md-3 list-inline">
			<li class="del1"><svg width="36px" height="36px"> <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#gift"></use> </svg></li>
			<li class="se1 text-xs-left">
			<h4>special gift cards</h4>
			<p>give a perfect gift</p>
			</li>
			</ul>
			<ul class="col-xs-12 col-sm-3 col-md-3 sborder list-inline">
			<li class="del4"><svg width="36px" height="36px"> <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#pay"></use> </svg></li>
			<li class="se1  text-xs-left">
			<h4>secure payment</h4>
			<p>100% secure payment</p>
			</li>
			</ul>
			<ul class="col-xs-12 col-sm-3 col-md-3 sborder list-inline">
			<li class="del2"><svg width="36px" height="36px"> <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#support"></use> </svg></li>
			<li class="se1  text-xs-left">
			<h4>24/7 support</h4>
			<p>online support 24/7</p>
			</li>
			</ul>
			<ul class="col-xs-12 col-sm-3 col-md-3 sborder list-inline">
			<li class="del3"><svg width="36px" height="36px"> <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#ship"></use> </svg></li>
			<li class="se1  text-xs-left">
			<h4>free shipping</h4>
			<p>on order over $101</p>
			</li>
			</ul>
			</div>
			</div>
			</div>
			</div>
		';
		
		
		$displayNav = Hook::getIdByName('displayNav');
		$displayNav1 = Hook::getIdByName('displayNav1');
		$displayNav2 = Hook::getIdByName('displayNav2');
		$displayTop = Hook::getIdByName('displayTop');
		$displayMegamenu = Hook::getIdByName('displayMegamenu');
		$displayImageSlider = Hook::getIdByName('displayImageSlider');
		$displayLeftColumn = Hook::getIdByName('displayLeftColumn');
		$displayRightColumn = Hook::getIdByName('displayRightColumn');
		$displayHome = Hook::getIdByName('displayHome');
		$displayPosition1 = Hook::getIdByName('displayPosition1');
		$displayPosition2 = Hook::getIdByName('displayPosition2');
		$displayPosition3 = Hook::getIdByName('displayPosition3');
		$displayPosition4 = Hook::getIdByName('displayPosition4');
		$displayPosition4 = Hook::getIdByName('displayPosition5');
		$displayPosition4 = Hook::getIdByName('displayPosition6');
		$displayFooterBefore = Hook::getIdByName('displayFooterBefore');
		$displayFooter = Hook::getIdByName('displayFooter');
		$displayFooterAfter = Hook::getIdByName('displayFooterAfter');
		
		
		$id_shop = Configuration::get('PS_SHOP_DEFAULT');
		
		/*install static Block*/
		$result = true;
		$result &= Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'inspcustomhtml` (`id_inspcustomhtml`, `hook`, `active`) 
			VALUES
			(1, "displayNav2", 1),
            (2, "displayTop", 1),			
			(3, "displayFooterBefore", 1)
			
			;'); 
		
		$result &= Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'inspcustomhtml_shop` (`id_inspcustomhtml`, `id_shop`,`active`) 
			VALUES 
			(1,'.$id_shop.', 1),
			(2,'.$id_shop.', 1),
			(3,'.$id_shop.', 1)			
			
			;');
		
		foreach (Language::getLanguages(false) as $lang)
		{
			$result &= Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'inspcustomhtml_lang` (`id_inspcustomhtml`, `id_shop`, `id_lang`, `title`, `content`) 
			VALUES 
			( "1", "'.$id_shop.'","'.$lang['id_lang'].'","Coupon", \''.$content_block1.'\'),
			( "2", "'.$id_shop.'","'.$lang['id_lang'].'","Head call", \''.$content_block2.'\'),
			( "3", "'.$id_shop.'","'.$lang['id_lang'].'","Inspire service", \''.$content_block3.'\')

			;');
		}
		return $result;
	}
}