/**
* 2007-2018 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2018 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*
* Don't forget to prefix your containers with your own identifier
* to avoid any conflicts with others containers.
*/

$(document).ready(function(){
	var loanding="<p class='loanding'></p>";
	
	
	$('#inspProductsCateHome .sub-cat-ul li').click(function(){
		var id_cat_main = $(this).attr('data-id-cat-main');
		var id_cat = $(this).attr('data-id-cat');
		var use_slider = $(this).attr('data-use_slider');
		var cat_info = $(this).attr('data-cat-info');
		var id_group = $(this).attr('data-id-group');
		var number_prod = $(this).attr('data-number-prod');
		var name_module = $(this).attr('data-insp-name-module');
		
		// $('.inspSub-cate #sub-cat-ul-'+id_group+''+cat_info+' li').removeClass('active');
		// $(this).addClass('active');
		$('.inspContentProduct-'+id_cat_main+'-'+id_group).html(loanding);
		
		getProductCatHome(id_group, id_cat_main, id_cat, use_slider ,number_prod, name_module);
		
	});
	
	/* inspProductsCatePosition1 */
	
	$('#inspProductsCatePosition1 .sub-cat-ul li').click(function(){
		var id_cat_main = $(this).attr('data-id-cat-main');
		var id_cat = $(this).attr('data-id-cat');
		var use_slider = $(this).attr('data-use_slider');
		var cat_info = $(this).attr('data-cat-info');
		var id_group = $(this).attr('data-id-group');
		var number_prod = $(this).attr('data-number-prod');
		var name_module = $(this).attr('data-insp-name-module');

		$('.inspSub-cate #sub-cat-ul-'+id_group+''+cat_info+' li').removeClass('active');
		$(this).addClass('active');
		$('.inspContentProduct-'+id_cat_main+'-'+id_group).html(loanding);
		
		getProductCatPosition1(id_group, id_cat_main, id_cat, use_slider, number_prod, name_module);
		
	});

		/* inspProductsCatePosition2 */
	
	$('#inspProductsCatePosition2 .sub-cat-ul li').click(function(){
		var id_cat_main = $(this).attr('data-id-cat-main');
		var id_cat = $(this).attr('data-id-cat');
		var use_slider = $(this).attr('data-use_slider');
		var cat_info = $(this).attr('data-cat-info');
		var id_group = $(this).attr('data-id-group');
		var number_prod = $(this).attr('data-number-prod');
		var name_module = $(this).attr('data-insp-name-module');

		$('.inspSub-cate #sub-cat-ul-'+id_group+''+cat_info+' li').removeClass('active');
		$(this).addClass('active');
		$('.inspContentProduct-'+id_cat_main+'-'+id_group).html(loanding);
		
		getProductCatPosition2(id_group, id_cat_main, id_cat, use_slider, number_prod, name_module);
		
	});
	
		/* inspProductsCatePosition3 */
	
	$('#inspProductsCatePosition3 .sub-cat-ul li').click(function(){
		var id_cat_main = $(this).attr('data-id-cat-main');
		var id_cat = $(this).attr('data-id-cat');
		var use_slider = $(this).attr('data-use_slider');
		var cat_info = $(this).attr('data-cat-info');
		var cat_info = $(this).attr('data-cat-info');
		var id_group = $(this).attr('data-id-group');
		var number_prod = $(this).attr('data-number-prod');
		var name_module = $(this).attr('data-insp-name-module');

		$('.inspSub-cate #sub-cat-ul-'+id_group+''+cat_info+' li').removeClass('active');
		$(this).addClass('active');
		$('.inspContentProduct-'+id_cat_main+'-'+id_group).html(loanding);
		
		getProductCatPosition3(id_group, id_cat_main, id_cat, use_slider, number_prod, name_module);
		
	});
	
		/* inspProductsCatePosition4 */
	
	$('#inspProductsCatePosition4 .sub-cat-ul li').click(function(){
		var id_cat_main = $(this).attr('data-id-cat-main');
		var id_cat = $(this).attr('data-id-cat');
		var use_slider = $(this).attr('data-use_slider');
		var cat_info = $(this).attr('data-cat-info');
		var id_group = $(this).attr('data-id-group');
		var number_prod = $(this).attr('data-number-prod');
		var name_module = $(this).attr('data-insp-name-module');

		$('.inspSub-cate #sub-cat-ul-'+id_group+''+cat_info+' li').removeClass('active');
		$(this).addClass('active');
		$('.inspContentProduct-'+id_cat_main+'-'+id_group).html(loanding);
		
		getProductCatPosition4(id_group, id_cat_main, id_cat, use_slider, number_prod, name_module);
		
	});
});


function getProductCatHome(id_group, id_cat_main, id_cat, use_slider, number_prod, name_module) {
		var url_page_cart = $('#inspProductsCateHome').attr('data-url_page_cart');
		var static_token = $('#inspProductsCateHome').attr('data-static_token');
		
		$.post(
		    $('#inspProductsCateHome').attr('data-insp_base_ssl'), 
			{id_Cat: id_cat, use_Slider: use_slider, id_Group: id_group, number_Prod: number_prod, name_Module: name_module, Url_Page_Cart : url_page_cart, Static_Token : static_token},
			function(data) 
			{ 
				$('.inspContentProduct-'+id_cat_main+'-'+id_group).html(data);
			})
			.fail(function(error, textStatus, errorThrown) 
			{ 
				$('.inspContentProduct-'+id_cat_main+'-'+id_group).html(error.responseText);
			});
	
}

/* inspProductsCatePosition1 */
function getProductCatPosition1(id_group, id_cat_main, id_cat, use_slider, number_prod, name_module) {
		var url_page_cart = $('#inspProductsCatePosition1').attr('data-url_page_cart');
		var static_token = $('#inspProductsCatePosition1').attr('data-static_token');
		
		$.post(
		    $('#inspProductsCatePosition1').attr('data-insp_base_ssl'), 
			{id_Cat: id_cat, use_Slider: use_slider, id_Group: id_group, number_Prod: number_prod, name_Module: name_module, Url_Page_Cart : url_page_cart, Static_Token : static_token},
			function(data) 
			{ 
				$('.inspContentProduct-'+id_cat_main+'-'+id_group).html(data);
			})
			.fail(function(error, textStatus, errorThrown) 
			{ 
				$('.inspContentProduct-'+id_cat_main+'-'+id_group).html(error.responseText);
			});
	
}

/* inspProductsCatePosition2 */
function getProductCatPosition2(id_group, id_cat_main, id_cat, use_slider, number_prod, name_module) {
		var url_page_cart = $('#inspProductsCatePosition2').attr('data-url_page_cart');
		var static_token = $('#inspProductsCatePosition2').attr('data-static_token');
		
		$.post(
		    $('#inspProductsCatePosition2').attr('data-insp_base_ssl'), 
			{id_Cat: id_cat, use_Slider: use_slider, id_Group: id_group, number_Prod: number_prod, name_Module: name_module, Url_Page_Cart : url_page_cart, Static_Token : static_token},
			function(data) 
			{ 
				$('.inspContentProduct-'+id_cat_main+'-'+id_group).html(data);
			})
			.fail(function(error, textStatus, errorThrown) 
			{ 
				$('.inspContentProduct-'+id_cat_main+'-'+id_group).html(error.responseText);
			});
	
}

/* inspProductsCatePosition3 */
function getProductCatPosition3(id_group, id_cat_main, id_cat, use_slider, number_prod, name_module) {
		var url_page_cart = $('#inspProductsCatePosition3').attr('data-url_page_cart');
		var static_token = $('#inspProductsCatePosition3').attr('data-static_token');
		
		$.post(
		    $('#inspProductsCatePosition3').attr('data-insp_base_ssl'), 
			{id_Cat: id_cat, use_Slider: use_slider, id_Group: id_group, number_Prod: number_prod, name_Module: name_module, Url_Page_Cart : url_page_cart, Static_Token : static_token},
			function(data) 
			{ 
				$('.inspContentProduct-'+id_cat_main+'-'+id_group).html(data);
			})
			.fail(function(error, textStatus, errorThrown) 
			{ 
				$('.inspContentProduct-'+id_cat_main+'-'+id_group).html(error.responseText);
			});
	
}

/* inspProductsCatePosition4 */
function getProductCatPosition4(id_group, id_cat_main, id_cat, use_slider, number_prod, name_module) {
		var url_page_cart = $('#inspProductsCatePosition4').attr('data-url_page_cart');
		var static_token = $('#inspProductsCatePosition4').attr('data-static_token');
		
		$.post(
		    $('#inspProductsCatePosition4').attr('data-insp_base_ssl'), 
			{id_Cat: id_cat, use_Slider: use_slider, id_Group: id_group, number_Prod: number_prod, name_Module: name_module, Url_Page_Cart : url_page_cart, Static_Token : static_token},
			function(data) 
			{ 
				$('.inspContentProduct-'+id_cat_main+'-'+id_group).html(data);
			})
			.fail(function(error, textStatus, errorThrown) 
			{ 
				$('.inspContentProduct-'+id_cat_main+'-'+id_group).html(error.responseText);
			});
	
}

