<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{inspproductcategory}prestashop>medium_item_03c2e7e41ffc181a4e84080b4710e81e'] = 'الجديد';
$_MODULE['<{inspproductcategory}prestashop>medium_item_2d0f6b8300be19cf35e89e66f0677f95'] = 'أضف إلى السلة';
$_MODULE['<{inspproductcategory}prestashop>inspproductcategory_tab_4f4b914d6db35e19101ff003c4e7ea3a'] = 'موضه';
